/* This file is empty */
/* It will be copied to ffconfig.h, then populated by cmake */
