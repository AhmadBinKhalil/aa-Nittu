int main()
{
	int i = nullptr;
	return 1;
}
